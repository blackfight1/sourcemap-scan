package app

import (
	"errors"
	"flag"
	"fmt"
	"net/url"
	"strings"
	"time"
)

type Config struct {
	Target            string
	OutputPath        string
	KatanaBin         string
	KatanaDepth       int
	KatanaConcurrency int
	KatanaParallelism int
	KatanaRateLimit   int
	KatanaExtraArgs   []string
	ScanWorkers       int
	HTTPTimeout       time.Duration
	TailBytes         int64
	MaxJSBytes        int64
	MaxMapBytes       int64
	UserAgent         string
}

func ParseConfig(args []string) (Config, error) {
	fs := flag.NewFlagSet("sourcemap-scan", flag.ContinueOnError)

	cfg := Config{}
	var extraArgs string

	fs.StringVar(&cfg.Target, "u", "", "single target URL to crawl")
	fs.StringVar(&cfg.OutputPath, "o", "", "write findings as JSONL to this file (default: stdout)")
	fs.StringVar(&cfg.KatanaBin, "katana-bin", "katana", "path to katana binary")
	fs.IntVar(&cfg.KatanaDepth, "katana-depth", 3, "katana crawl depth")
	fs.IntVar(&cfg.KatanaConcurrency, "katana-concurrency", 10, "katana fetch concurrency")
	fs.IntVar(&cfg.KatanaParallelism, "katana-parallelism", 3, "katana input parallelism")
	fs.IntVar(&cfg.KatanaRateLimit, "katana-rate-limit", 30, "katana request rate limit per second")
	fs.StringVar(&extraArgs, "katana-extra-args", "", "additional katana arguments, split on spaces")
	fs.IntVar(&cfg.ScanWorkers, "scan-workers", 10, "number of JS scanning workers")
	fs.DurationVar(&cfg.HTTPTimeout, "http-timeout", 15*time.Second, "HTTP timeout for JS and map fetches")
	fs.Int64Var(&cfg.TailBytes, "tail-bytes", 8192, "number of bytes requested from the end of each JS asset")
	fs.Int64Var(&cfg.MaxJSBytes, "max-js-bytes", 16*1024*1024, "maximum JS response bytes to read before aborting")
	fs.Int64Var(&cfg.MaxMapBytes, "max-map-bytes", 10*1024*1024, "maximum map response bytes to read before aborting")
	fs.StringVar(&cfg.UserAgent, "user-agent", "sourcemap-scan/0.1", "user agent used for JS and map requests")

	fs.Usage = func() {
		fmt.Fprintf(fs.Output(), "Usage: sourcemap-scan -u https://target.tld [options]\n\n")
		fs.PrintDefaults()
	}

	if err := fs.Parse(args); err != nil {
		return Config{}, err
	}

	cfg.Target = strings.TrimSpace(cfg.Target)
	if cfg.Target == "" {
		return Config{}, errors.New("target URL is required via -u")
	}

	parsed, err := url.Parse(cfg.Target)
	if err != nil || parsed.Scheme == "" || parsed.Host == "" {
		return Config{}, fmt.Errorf("invalid target URL: %q", cfg.Target)
	}

	if cfg.KatanaDepth < 1 {
		return Config{}, errors.New("katana-depth must be >= 1")
	}
	if cfg.KatanaConcurrency < 1 {
		return Config{}, errors.New("katana-concurrency must be >= 1")
	}
	if cfg.KatanaParallelism < 1 {
		return Config{}, errors.New("katana-parallelism must be >= 1")
	}
	if cfg.KatanaRateLimit < 1 {
		return Config{}, errors.New("katana-rate-limit must be >= 1")
	}
	if cfg.ScanWorkers < 1 {
		return Config{}, errors.New("scan-workers must be >= 1")
	}
	if cfg.TailBytes < 512 {
		return Config{}, errors.New("tail-bytes must be >= 512")
	}
	if cfg.MaxJSBytes < cfg.TailBytes {
		return Config{}, errors.New("max-js-bytes must be >= tail-bytes")
	}
	if cfg.MaxMapBytes < 1024 {
		return Config{}, errors.New("max-map-bytes must be >= 1024")
	}
	if cfg.HTTPTimeout <= 0 {
		return Config{}, errors.New("http-timeout must be > 0")
	}

	if extraArgs != "" {
		cfg.KatanaExtraArgs = strings.Fields(extraArgs)
	}

	return cfg, nil
}
