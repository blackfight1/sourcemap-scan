package scan

import (
	"context"
	"fmt"
	"os"
	"sync"
	"sync/atomic"

	"sourcemap-scan/internal/app"
	"sourcemap-scan/internal/httpx"
	"sourcemap-scan/internal/katana"
	"sourcemap-scan/internal/model"
	"sourcemap-scan/internal/output"
	"sourcemap-scan/internal/sourcemap"
)

type Service struct {
	cfg          app.Config
	katanaRunner *katana.Runner
	httpClient   *httpx.Client
}

func NewService(cfg app.Config) (*Service, error) {
	return &Service{
		cfg:          cfg,
		katanaRunner: katana.NewRunner(cfg),
		httpClient:   httpx.New(cfg.HTTPTimeout, cfg.UserAgent),
	}, nil
}

func (s *Service) Run(ctx context.Context) error {
	writer, err := output.NewJSONLWriter(s.cfg.OutputPath)
	if err != nil {
		return err
	}
	defer writer.Close()

	jsURLs, err := s.katanaRunner.CollectJSURLs(ctx)
	if err != nil {
		return err
	}

	fmt.Fprintf(os.Stderr, "discovered %d JavaScript assets from katana\n", len(jsURLs))

	jobs := make(chan string)
	findings := make(chan model.Finding)

	var workerWG sync.WaitGroup
	var scannedCount atomic.Int64
	var findingCount atomic.Int64

	for i := 0; i < s.cfg.ScanWorkers; i++ {
		workerWG.Add(1)
		go func() {
			defer workerWG.Done()
			for assetURL := range jobs {
				select {
				case <-ctx.Done():
					return
				default:
				}

				scannedCount.Add(1)
				assetFindings, err := s.scanAsset(ctx, assetURL)
				if err != nil {
					continue
				}

				for _, finding := range assetFindings {
					select {
					case <-ctx.Done():
						return
					case findings <- finding:
					}
				}
			}
		}()
	}

	go func() {
		defer close(jobs)
		for _, assetURL := range jsURLs {
			select {
			case <-ctx.Done():
				return
			case jobs <- assetURL:
			}
		}
	}()

	go func() {
		workerWG.Wait()
		close(findings)
	}()

	for finding := range findings {
		if err := writer.WriteFinding(finding); err != nil {
			return err
		}
		findingCount.Add(1)
	}

	if err := ctx.Err(); err != nil {
		return err
	}

	fmt.Fprintf(
		os.Stderr,
		"scanned %d JavaScript assets, found %d valid source maps\n",
		scannedCount.Load(),
		findingCount.Load(),
	)

	return nil
}

func (s *Service) scanAsset(ctx context.Context, assetURL string) ([]model.Finding, error) {
	jsResp, err := s.httpClient.FetchTail(ctx, assetURL, s.cfg.TailBytes, s.cfg.MaxJSBytes)
	if err != nil {
		return nil, err
	}

	candidates := sourcemap.DiscoverExplicitCandidates(jsResp.URL, jsResp.Header, jsResp.Body)
	if len(candidates) == 0 {
		if guessed, ok := sourcemap.GuessAdjacentCandidate(jsResp.URL); ok {
			candidates = append(candidates, guessed)
		}
	}

	if len(candidates) == 0 {
		return nil, nil
	}

	seen := make(map[string]struct{})
	findings := make([]model.Finding, 0, len(candidates))

	for _, candidate := range candidates {
		if _, ok := seen[candidate.URL]; ok {
			continue
		}
		seen[candidate.URL] = struct{}{}

		validation, err := sourcemap.ValidateRemoteMap(ctx, s.httpClient, candidate.URL, s.cfg.MaxMapBytes)
		if err != nil {
			continue
		}

		findings = append(findings, model.Finding{
			Target:              s.cfg.Target,
			AssetURL:            jsResp.URL,
			MapURL:              validation.FinalURL,
			RequestedMapURL:     candidate.URL,
			DiscoveredBy:        candidate.Method,
			SourceMappingURLRaw: candidate.SourceMappingValue,
			StatusCode:          validation.StatusCode,
			ContentType:         validation.ContentType,
			SourcesCount:        validation.SourcesCount,
			NamesCount:          validation.NamesCount,
			HasSourcesContent:   validation.HasSourcesContent,
			File:                validation.File,
		})
	}

	return findings, nil
}
