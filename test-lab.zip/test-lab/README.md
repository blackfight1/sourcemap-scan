# test-lab

这是一个最小化的本地 sourcemap 靶场，用来验证这几件事：

1. `sourcemap-scan pipeline` 能否发现暴露的 `.js.map`
2. `shuji` 能否还原 `sourcesContent`
3. `trufflehog` 能否被正确调用
4. `process-workers` 并发时，是否会对多个命中分别发通知

这个靶场分两种验证方式：

- 真实链路验证
  使用你 VPS 上真实安装的 `trufflehog`
- 并发通知验证
  使用 `bin/trufflehog-verified-testkeys.sh`，稳定返回 3 条 `Verified=true`

## 目录

```text
test-lab/
  site/
    index.html
    assets/
      a.js
      a.js.map
      b.js
      b.js.map
      c.js
      c.js.map
  bin/
    trufflehog-verified-testkeys.sh
  server.js
  webhook-capture.js
```

## 前置要求

- VPS 已安装：
  - `node`
  - `katana`
  - `shuji`
  - `trufflehog`
  - `sourcemap-scan`
- 端口 `18120` 和 `18121` 未被占用

## 启动靶场

在 `test-lab/` 目录执行：

```bash
chmod +x bin/trufflehog-verified-testkeys.sh
nohup node server.js > server.log 2>&1 &
nohup node webhook-capture.js > webhook.log 2>&1 &
```

检查页面：

```bash
curl -s http://127.0.0.1:18120/
curl -s http://127.0.0.1:18120/assets/a.js
curl -s http://127.0.0.1:18120/assets/a.js.map
```

## 方式一：真实 TruffleHog

这一步验证真实工具链是否能完整跑通。

```bash
sourcemap-scan pipeline \
  -u http://127.0.0.1:18120 \
  -base-dir /tmp/smap-lab-real \
  -target-workers 1 \
  -process-workers 3 \
  -katana-bin /usr/local/bin/katana \
  -shuji-bin /usr/bin/shuji \
  -trufflehog-bin /usr/local/bin/trufflehog
```

查看结果：

```bash
sed -n '1,20p' /tmp/smap-lab-real/results/summaries.jsonl
```

注意：

- 这批测试值是按 `trufflesecurity/test_keys` 风格写入的
- 真实 `trufflehog` 是否命中、是否 `Verified=true`，取决于你 VPS 上的版本和检测器行为
- 所以这一步主要验证“发现 map + 还原 + 扫描调用”链路

## 方式二：并发通知验证

这一步稳定验证：

- 3 个 sourcemap 被并发处理
- 每个 sourcemap 产出 1 条 `Verified=true`
- webhook 捕获器收到 3 条通知

```bash
sourcemap-scan pipeline \
  -u http://127.0.0.1:18120 \
  -base-dir /tmp/smap-lab-fake \
  -target-workers 1 \
  -process-workers 3 \
  -katana-bin /usr/local/bin/katana \
  -shuji-bin /usr/bin/shuji \
  -trufflehog-bin "$(pwd)/bin/trufflehog-verified-testkeys.sh" \
  -feishu-webhook http://127.0.0.1:18121
```

查看结果：

```bash
sed -n '1,20p' /tmp/smap-lab-fake/results/summaries.jsonl
wc -l webhook-bodies.jsonl
tail -n 50 webhook-bodies.jsonl
```

预期：

- `results/summaries.jsonl` 有 3 行
- 每行都有：
  - `hits_total: 1`
  - `verified_hits: 1`
  - `notified: 1`
- `webhook-bodies.jsonl` 有 3 行

## 清理

停止服务：

```bash
pkill -f 'node server.js' || true
pkill -f 'node webhook-capture.js' || true
```

删除测试输出：

```bash
rm -rf /tmp/smap-lab-real /tmp/smap-lab-fake
rm -f webhook-bodies.jsonl server.log webhook.log
```
