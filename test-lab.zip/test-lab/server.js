const http = require("http");
const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "site");
const host = "127.0.0.1";
const port = 18120;

const mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".map": "application/json; charset=utf-8",
};

http
  .createServer((req, res) => {
    const cleanPath = req.url.split("?")[0];
    const relPath = cleanPath === "/" ? "/index.html" : cleanPath;
    const filePath = path.join(root, relPath);

    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("not found");
        return;
      }

      res.writeHead(200, {
        "Content-Type": mime[path.extname(filePath)] || "application/octet-stream",
      });
      res.end(data);
    });
  })
  .listen(port, host, () => {
    console.log(`lab server listening on http://${host}:${port}`);
  });
