console.log("lab asset a");
//# sourceMappingURL=a.js.map
