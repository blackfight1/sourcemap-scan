console.log("lab asset b");
//# sourceMappingURL=b.js.map
