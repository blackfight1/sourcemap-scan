console.log("lab asset c");
//# sourceMappingURL=c.js.map
