const http = require("http");
const fs = require("fs");
const path = require("path");

const host = "127.0.0.1";
const port = 18121;
const outputPath = path.join(__dirname, "webhook-bodies.jsonl");

try {
  fs.unlinkSync(outputPath);
} catch (_) {}

http
  .createServer((req, res) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => {
      fs.appendFileSync(outputPath, body + "\n", "utf8");
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end('{"code":0}');
    });
  })
  .listen(port, host, () => {
    console.log(`webhook capture listening on http://${host}:${port}`);
  });
